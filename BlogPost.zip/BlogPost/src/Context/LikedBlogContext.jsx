import { createContext } from "react";

const LikedBlogContext = createContext();

export default LikedBlogContext;
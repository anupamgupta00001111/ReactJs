// JavaScript Part

const assignment = ( function() {

    var students = []

    function FormSubmit(){

        // Method used to prevent the default behaviour of the element
        event.preventDefault();


         // Getting email of the user
        var email = document.getElementById("email").value;
        // Validating the email
        if(! assignment.validate(email)){
            alert('Invalid Email Address')
            return 
        }


        // Getting user image
        var imagelink = document.getElementById("imglink").value;
        // if link not available provide default image
        if(! imagelink){
            imagelink = 'https://www.kindpng.com/picc/m/24-248253_user-profile-default-image-png-clipart-png-download.png';
        }

        
        // Getting user skills
        var skills = [];
        var skill_selected = document.getElementsByName('skills');
        for (let i = 0; i < skill_selected.length; i++) {
            if (skill_selected[i].checked) {
                skills.push(skill_selected[i].value);
            }
        }
        
        students.push({
            name: document.getElementById("name").value,
            gender: document.querySelector('input[name="gender"]:checked').value,
            email: email,
            website: document.getElementById("website").value,
            image: imagelink,
            skills: skills

        })



        assignment.addStudent(students[students.length -1])


        
        document.getElementById("myform").reset();

    }




    // Function to add student to 
    function AddStudentToList(student){
        
        // Creating the new row to dynamic id in table
        var newRow = dynamic.insertRow();
       
       // Creating two cells in the above created row
        var cell1 = newRow.insertCell(0);
        var cell2 = newRow.insertCell(1);


        // HTML code to insert in cell1
        cell1.innerHTML = 
        '<tr>' +
        '<td>' +
        '<p id="nameView">' + student.name + '</p>' +
        '<p id="genderView">' + student.gender + '</p>' +
        '<p id="emailView">' + student.email + '</p>' +
        '<p id="websiteView"><a href="' + student.website + '  " target="_blank">' + student.website + ' </a></p>' +
        '<p id="skillsView">' + student.skills + '</p>' +
        '</td>' +
        '</tr>';

        // HTML code to insert in cell2
        cell2.innerHTML =
        '<tr>' +
        '<td class="imgDetais">' +
        '<img src=' + '"' + student.image + '" >' +
        '</td>' +
        '</tr>';


    }




    // Function to validate the email
    function ValidateEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }



    
    // return variable of the function
    return {
        validate: ValidateEmail,
        addStudent: AddStudentToList,
        onsubmit: FormSubmit
    }
}) ();


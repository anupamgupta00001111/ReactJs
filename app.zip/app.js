const dotenv = require("dotenv");
dotenv.config({path:"config.env"});

const path = require("path");
const express = require("express");
const app = express();

const port = process.env.PORT || 80;

app.use("/public",express.static(path.join(__dirname,"static")))

app.get("/", (req, res)=>{
    res.sendFile(path.join(__dirname,"static","index.html"));
});

app.listen(port,()=>{
    console.log(`Application is listening on PORT:${port}`)
});